// plot.h
#ifndef PLOT_H
#define PLOT_H

void ascii_plot_function(int k, double xmin, double xmax, int width, int height);

#endif