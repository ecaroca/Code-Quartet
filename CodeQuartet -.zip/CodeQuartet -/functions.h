// functions.h
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

class Functions {
public:
    static double f_eval(int k, double x);
    static double df_eval(int k, double x);
};

#endif
