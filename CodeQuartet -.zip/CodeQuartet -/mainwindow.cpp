#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "informacion.h"
#include "calculus.h"
#include "functions.h"
#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QtCharts/QLineSeries>
#include <QMessageBox>
#include <cmath>


double MainWindow::getA()
{
    return ui->avalor->text().toDouble();
}

double MainWindow::getB()
{
    return ui->bvalor->text().toDouble();
}

void MainWindow::setResultado(double r)
{
    ui->resultado->setText(QString::number(r));
}

int MainWindow::getK() {
    return ui->kvalor->text().toInt();  // 1=sin, 2=cos, etc.
}

int MainWindow::getSide(){
    int s = ui->nvalor->text().toInt();
    return (s >= 0 ? 1 : -1);
}

//Funciones extra
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_acerca_clicked()
{
    informacion* ventana2 = new informacion(this);
    ventana2->show();
}

//FUNCIONES PARA OPERACIONES BASICAS
void MainWindow::on_suma_clicked()
{
    double A = getA();
    double B = getB();
    setResultado(A + B);
}


void MainWindow::on_resta_clicked()
{
    double A = getA();
    double B = getB();
    setResultado(A - B);
}


void MainWindow::on_multiplicar_clicked()
{
    double A = getA();
    double B = getB();
    setResultado(A * B);
}

void MainWindow::on_dividir_clicked()
{
    double A = getA();
    double B = getB();
    if (B == 0) {
        ui->resultado->setText("Error: B=0");
        return;
    }
    setResultado(A / B);
}


void MainWindow::on_potencia_clicked()
{
    double A = getA();
    double B = getB();

    setResultado(std::pow(A, B));
}

void MainWindow::on_raiz_clicked()
{
    double A = getA();
    if (A<0){
        ui->resultado->setText("Error: A<0");
    return;
    }

    double B = getB();

    setResultado(std::pow(A, 1/B));
}

//FUNCIONES TRIGONOMETRICAS


void MainWindow::on_seno_clicked()
{
    double A = getA();
    setResultado(std::sin(A));
}

void MainWindow::on_coseno_clicked()
{
    double A = getA();
    setResultado(std::cos(A));
}

void MainWindow::on_exponencial_clicked()
{
    double A = getA();
    setResultado(std::exp(A));
}

void MainWindow::on_logaritmo_clicked()
{
    double A = getA();
    if (A<0){
        ui->resultado->setText("Error: A<0");
        return;
    }
    setResultado(std::log(A));
}

void MainWindow::on_cuadrado_clicked()
{
    double A = getA();
    setResultado(A*A);
}

void MainWindow::on_polinomio_clicked()
{
    double A = getA();
    setResultado(A*A*A - A - 2.0);
}

//FUINCIONES TRIGONOMICAS DERIVADAS

void MainWindow::on_seno_2_clicked()
{
    double A = getA();
    setResultado(std::cos(A));
}


void MainWindow::on_coseno_2_clicked()
{
    double A = getA();
    setResultado(-std::sin(A));
}


void MainWindow::on_exponencial_2_clicked()
{
    double A = getA();
    setResultado(std::exp(A));
}

void MainWindow::on_logaritmo_2_clicked()
{
    double A = getA();
    setResultado(1/A);
}

void MainWindow::on_cuadrado_2_clicked()
{
    double A = getA();
    setResultado(2*A);
}

void MainWindow::on_polinomio_2_clicked()
{
    double A = getA();
    setResultado(3*A*A - 1.0);
}

//FUNCIONES DE CALCULO

void MainWindow::on_limite_clicked()
{
    int k = getK();        // qué función f_k(x) usar
    double a = getA();     // punto al que se aproxima
    int side = getSide();  // -1 izquierda, +1 derecha

    double lim = Calculus::limit_numeric(k, a, side);
    setResultado(lim);
}

void MainWindow::on_derivada_clicked()
{
    int k = getK();
    double x0 = getA();   // Punto donde derivar
    double h  = getB();   // Paso (si 0 → usa interno 1e-5)

    double d = Calculus::deriv_central(k, x0, h);
    setResultado(d);
}

void MainWindow::on_integral_clicked()
{
    int k = getK();

    double a = getA();
    double b = getB();
    int n = getSide();  // subdivisiones

    double I = Calculus::integral_simpson(k, a, b, n);
    setResultado(I);
}


//Matriz


void MainWindow::on_resolverAxB_clicked()
{
    // Matriz A 2x2 desde los QLineEdit nuevos
    double a11 = ui->a11->text().toDouble();
    double a12 = ui->a12->text().toDouble();
    double a21 = ui->a21->text().toDouble();
    double a22 = ui->a22->text().toDouble();

    // Vector b lo tomamos de los campos A y B de arriba
    double b1 = getA(); // campo A
    double b2 = getB(); // campo B

    // Determinante
    double det = a11 * a22 - a12 * a21;

    if (std::fabs(det) < 1e-12) {
        QMessageBox::warning(this, "Matrices",
                             "La matriz A es singular (determinante ≈ 0).\n"
                             "No se puede resolver Ax = b.");
        return;
    }

    // Cramer para 2x2
    double x1 = ( b1 * a22 - b2 * a12 ) / det;
    double x2 = ( a11 * b2 - a21 * b1 ) / det;

    // Mostrar en el QLineEdit Resultado
    ui->resultado->setText(
        QString("x1 = %1, x2 = %2").arg(x1).arg(x2)
        );
}


void MainWindow::on_determinante_clicked()
{
    // Matriz A 2x2 desde los QLineEdit nuevos
    double a11 = ui->a11->text().toDouble();
    double a12 = ui->a12->text().toDouble();
    double a21 = ui->a21->text().toDouble();
    double a22 = ui->a22->text().toDouble();

    double det = a11 * a22 - a12 * a21;

    setResultado(det); // se muestra en el campo "Resultado"
}


void MainWindow::on_inversa_clicked()
{
    double a11 = ui->a11->text().toDouble();
    double a12 = ui->a12->text().toDouble();
    double a21 = ui->a21->text().toDouble();
    double a22 = ui->a22->text().toDouble();

    double det = a11 * a22 - a12 * a21;

    if (std::fabs(det) < 1e-12) {
        QMessageBox::warning(this, "Matrices",
                             "La matriz A es singular (determinante ≈ 0).\n"
                             "No tiene inversa.");
        return;
    }

    double inv11 =  a22 / det;
    double inv12 = -a12 / det;
    double inv21 = -a21 / det;
    double inv22 =  a11 / det;

    ui->resultado->setText(
        QString("[[%1  %2];  [%3  %4]]")
            .arg(inv11).arg(inv12)
            .arg(inv21).arg(inv22)
        );
}



void MainWindow::on_evaluarFk_clicked()
{
    int k = getK();
    double x = getA();

    double y = Functions::f_eval(k, x);
    setResultado(y);
}

void MainWindow::on_graficarFk_clicked()
{
    int k = getK();        // qué función f_k(x)
    double xMin = getA();  // límite inferior
    double xMax = getB();  // límite superior

    if (xMax <= xMin) {
        QMessageBox::warning(this, "Gráfico","B debe ser mayor que A para graficar.");
        return;
    }

    QLineSeries *series = new QLineSeries();
    int puntos = 200;
    double paso = (xMax - xMin) / (puntos - 1);

    for (int i = 0; i < puntos; ++i) {
        double x = xMin + i * paso;
        double y = Functions::f_eval(k, x);

        if (std::isnan(y) || std::isinf(y))
            continue; // saltar valores no válidos

        series->append(x, y);
    }

    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->createDefaultAxes();
    chart->setTitle(QString("f_%1(x)").arg(k));

    QChartView *view = new QChartView(chart);
    view->setRenderHint(QPainter::Antialiasing);
    view->resize(600, 400);
    view->setWindowTitle("Gráfico de f_k(x)");
    view->show();
}
