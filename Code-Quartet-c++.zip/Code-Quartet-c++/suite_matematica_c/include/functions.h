// functions.h - catálogo de funciones f(x) para opciones
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

double f_eval(int k, double x);

#endif