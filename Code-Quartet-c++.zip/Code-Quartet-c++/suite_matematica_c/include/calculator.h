// calculator.h
#ifndef CALCULATOR_H
#define CALCULATOR_H

double calc_suma(double a, double b);
double calc_resta(double a, double b);
double calc_mult(double a, double b);
double calc_div(double a, double b);
double calc_pot(double base, double expn);
double calc_raiz(double x);

#endif